package application.android.com.zhaozehong.activities;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;


public class TranslucentActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
