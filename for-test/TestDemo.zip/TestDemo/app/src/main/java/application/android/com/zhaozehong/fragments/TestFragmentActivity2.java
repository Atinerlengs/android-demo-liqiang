package application.android.com.zhaozehong.fragments;

public class TestFragmentActivity2 extends TestFragmentActivity {
}
