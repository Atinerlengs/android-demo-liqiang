package application.android.com.zhaozehong.action;

import android.app.Activity;

public class ServiceTestAction extends Action {

    public ServiceTestAction(Activity activity) {
        super(activity);
    }

    @Override
    public String getName() {
        return "ServiceTest";
    }

    @Override
    public void doAction() {

    }
}
